package com.finance.demobank_v2.bankingcore;

public enum TransactionType {
    TRANSFER,DEPOSIT
}
