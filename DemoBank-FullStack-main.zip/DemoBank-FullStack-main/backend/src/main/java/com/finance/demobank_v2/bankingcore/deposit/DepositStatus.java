package com.finance.demobank_v2.bankingcore.deposit;

public enum DepositStatus {
    PENDING, APPROVED,  REJECTED
}
