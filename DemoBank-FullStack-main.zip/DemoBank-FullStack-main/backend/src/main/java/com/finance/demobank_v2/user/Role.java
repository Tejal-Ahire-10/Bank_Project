package com.finance.demobank_v2.user;

public enum Role {
    ADMIN,USER
}
